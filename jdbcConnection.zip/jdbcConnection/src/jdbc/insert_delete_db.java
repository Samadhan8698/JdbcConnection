package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class insert_delete_db {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/feb", "root", "Sama@123");

		String query = "insert into student(stud_id,name) values(?,?)";
		PreparedStatement stmt = conn.prepareStatement(query);
		stmt.setInt(1,6 );
	stmt.setString(2, "SAM");

		stmt.executeUpdate();
		System.out.println("row inserted: ");

		conn.close();
	}

}
