package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class cnnection2db {

	public static void main(String[] args) throws SQLException {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/feb", "root", "Sama@123");
			String q = "select * from student";
			Statement stmt = conn.createStatement();
			ResultSet set = stmt.executeQuery(q);

			while (set.next()) {
				System.out.println(set.getInt(1) + " " + set.getString("name"));
			}

			conn.close();
			System.out.println("Success");
		} catch (ClassNotFoundException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
