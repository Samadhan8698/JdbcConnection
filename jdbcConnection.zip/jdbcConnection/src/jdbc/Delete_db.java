package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Delete_db {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/feb", "root", "Sama@123");
		String query = "DELETE FROM student where stud_id = ?";
		PreparedStatement stmt = conn.prepareStatement(query);
		int id = 2;
		stmt.setInt(1, id);
		int row = stmt.executeUpdate();
		System.out.println("row is deleted successfully " + row);

	}

}
