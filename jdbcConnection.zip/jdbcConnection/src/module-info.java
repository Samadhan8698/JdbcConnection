/**
 * 
 */
/**
 * 
 */
module jdbcConnection {
	requires java.sql;
}